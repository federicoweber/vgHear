<script>

/*
	css hack for Like button 
	.connect_widget_not_connected_text{display:none!important;}
	.profileimage{display:none!important;}
	.name_block{display:none!important;}
	.connect_widget_connected_text{display:none!important;}
	.unlike_span{display:none!important;}
	.connect_widget_unlike_link{display:none!important;}
*/

</script>

<!doctype html>

<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<html class="no-js" lang="en"  xmlns:fb="https://www.facebook.com/2008/fbml">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title></title>
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="_/css/reset.css">
	<link rel="stylesheet" href="app/css/styles.css">	

	<script src="_/js/libs/modernizer/modernizr-2.0.6.min.js"></script>

</head>
<body>
<div id="fb-root"></div>

<div id="container">
	<!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
	<!--fb:like href="https://www.facebook.com/pages/vanGoGh/109976239550" send="false" width="450" show_faces="true" action="like" font=""></fb:like-->
	<div id="loader"><p></p></div>
    </header>
	<!-- <div id="fb-root"></div> -->
	<div id="main" role="main">
	</div>
</div> <!--! end of #container -->

<!-- Handlebars does not officillly support noConflict mode so we load it here -->
<script src="_/js/libs/handlebars/handlebars-1.0.0.beta.6.js"></script>


<!-- script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-30531423-1']);
	_gaq.push(['_setDomainName', 'none']);
	_gaq.push(['_setAllowLinker', 'true']);
	_gaq.push(['_trackPageview']);

	(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
</script-- >

<!-- KICK IN our app loading require.js and main.js -->
<script data-main="_/js/main" src="_/js/libs/require/require.js"></script>

</body>
</html>

	})();
</script-- >

<!-- KICK IN our app loading require.js and main.js -->
<script data-main="_/js/main" src="_/js/libs/require/require.js"></script>

</body>
</html>
