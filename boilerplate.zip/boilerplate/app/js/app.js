/*----------------------------------------------------------------------------------------- 

  This is the main App class. 

  It should return an init function. That called from the main.js will bootstrap the app


-----------------------------------------------------------------------------------------*/

define([
  'jQuery'
  , 'Underscore'
  , 'Backbone'
  , 'app/js/router' 
  ], function($, _, Backbone, Router){

  var init = function(){
    Router.initialize();
  }

  return {
    init: init
  };
});