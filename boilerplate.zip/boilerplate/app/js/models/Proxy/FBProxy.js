define([
  'jQuery'
  , 'Underscore'
  , 'Backbone',
], function($, _, Backbone){

  var init, accessToken,
  _fbMeHandler,
  instance,
  loc,
  qry,
  flipImgModel,
  ownerModel,
  friendModel,
  friendsListModel,
  giornataStortaModel,
  secureGraph='https://graph.facebook.com/',
  ownerObject={},
  friendObject={};
  friendObject.name='zulfeekar cheriyampurath';
  friendObject.id='702759435';
  friendObject.friend_thumb=secureGraph+friendObject.id+'/picture?type=small'
  ;

  var appConfig = {} 

  // Local 
  appConfig = {
		appId: "344189085628765"
	,	appSecret: "57d2c4617c694fd27d4afa5f20e2944f"
	,	appUrl: "https://localhost/giornatastorta"
	,	appFbUrl: "https://apps.facebook.com/giornatastorta/"
	,	appName: "giornatastorta"
  };

  // Staging 
  /* appConfig = {
   		appId: "365787593471472"
   	,	appSecret: "dc9d68bc38b8f2fb7034ecbae72f34b6"
   	,	appUrl: "https://barillafb.stage.fullsix.it/gocciole/giornatastorta/"
   	,	appFbUrl: "https://apps.facebook.com/gstorta_test/"
   	,	appName: "gstorta_test"
   }; */ 

  // Online 
  /* appConfig = {
   		appId: "429777840371795"
   	,	appSecret: "dd77ae19bac881feb785cf9b06513c51"
   	,	appUrl: "https://fb.barilla.com/gocciole/giornatastorta/"
   	,	appFbUrl: "https://apps.facebook.com/gstorta/"
   	,	appName: "gstorta"
   }; */

  init=function(handler){
 //  	var ourTop = _.clone(top.location);
	// if(ourTop.href === location.href)
	// {
	//   redirect();
	//   return;
	// }
	
	_fbMeHandler = handler;
	var e = document.createElement('script');
	e.type = 'text/javascript';
	e.src = document.location.protocol +'//connect.facebook.net/en_US/all.js';
	e.async = true;
	$('#fb-root').append(e);


	window.fbAsyncInit = function() {
		FB.init({appId: appConfig.appId,
		  status: true,
		  cookie: true,
		  xfbml: true,
		  channelUrl : appConfig.appUrl+'/channel.html'});

		//grant App credential
		//  $token_url = "https://graph.facebook.com/oauth/access_token?" .
		//   "client_id=" . $app_id .
		//   "&client_secret=" . $app_secret .
		//   "&grant_type=client_credentials";

		// $app_access_token = file_get_contents($token_url);


		FB.getLoginStatus(function(response) {

			//loc = window.top.location.href;
			st='https://apps.facebook.com'
			if(response.session){
				login();
			}
			else if (response.status === 'connected') {
			  ownerObject.id=response.authResponse.userID;
			  accessToken = response.authResponse.accessToken;
			  login();
			} 
			else if (response.status === 'not_authorized') {
			  redirect();
			} else {
			  redirect();
			}
	   });
		
		FB.Event.subscribe('auth.logout', function(response) {
			logout();
		});
		
		FB.Event.subscribe('edge.create', function(href, widget,yeppo) {
			//alert("Like button clicked");
		});
	};

	
  };
  function redirect(){

	  var qry = (!window.experience_id) ? '' : '/experience.php?experience_id='+window.experience_id;
	  if(qry != ''){
	  	window.top.location.href='https://www.facebook.com/dialog/oauth?client_id='+appConfig.appId+'&scope=publish_actions,email'+'&redirect_uri='+appConfig.appUrl+qry;
	  } else {
		  window.top.location.href='https://www.facebook.com/dialog/oauth?client_id='+appConfig.appId+'&scope=publish_actions,email'+'&redirect_uri='+appConfig.appFbUrl;
	  }
  }
  function login(){
	  FB.api('/me', function(response) {
	  		if(response.error){
	  			var qry = (!window.experience_id) ? '' : '?experience_id='+window.experience_id;

  				//window.top.location.href= appConfig.appUrl+'/experience.php'+qry ;
  				redirect();
	  		} else {
			  ownerObject=response;
			  setTimeout(function(){
			   VGEVENT_GLOBALS.userConnectedToFB(window.experience_id ? {experience_id: window.experience_id }: response);
			  },300)  
			}
	  });
  };

  function logout(){
  
  };
  
  function getLoginStatus(){
	
  };
  //stream publish method
  function streamPublish(name, description, caption, message, media, hrefTitle, hrefLink, userPrompt){
		FB.ui(
		{
			method: 'stream.publish',
			message: message.replace('&egrave;','è') || '',
			attachment: {
				name: name,
				caption: caption || '',
				description: description || '',
				href: hrefLink,
				media: media || {}
			},
			action_links: [
				{ text: hrefTitle, href: hrefLink }
			],
			target: 'self',
			user_prompt_message: userPrompt || '',
			user_message: message || ''
		},
		function(response) {

		});

	};

   function showStream(){
		FB.api('/me', function(response) {
			streamPublish(response.name, 'ererererere', 'rererere', 'ewewewwew', "ewewewewew");
		});
	};
	function share(){
		var share = {
			method: 'stream.share',
			u: 'wwww.google.com'
		};

		// FB.ui(share, function(response) { //console.log(response); });
	};
   var graphStreamPublish=function(name, description, caption, message, picture, actionText, hrefLink, callback){
		var hrefLink = hrefLink? hrefLink : ''
		,	data=
		{
			message: message.replace('&egrave;','è') || '',
			display: 'iframe',
			caption: caption || '',
			name: name || '',
			description: description || '',
			picture: picture || '',
			link: hrefLink,  // Go here if user click the picture
			target: 'self',
			actions: [{ name: actionText || '', link: hrefLink}],
		}
		FB.api('/me/feed', 'post', data, function(response) {
			if (!response || response.error) {
				callback(response.error);
			} else {
				////alert('Post ID: ' + response.id);
				callback();
			}
		});

	};

	var sendRequestFromApp = function(user_id, message){

		var user_id = user_id
		, message = message
		;

		//console.log(appConfig);

		$.post("https://graph.facebook.com/oauth/access_token?client_id="+appConfig.appId+"&client_secret="+appConfig.appSecret+"&grant_type=client_credentials", function(res){
			//console.log("got access_token");
			accessToken = res;

			$.post("https://graph.facebook.com/"+user_id+'/apprequests?message='+message+'&'+accessToken+'&method=post',{}, function(){
				//alert("success");
			});
		});


	};

	function fqlQuery(){
		FB.api('/me', function(response) {
			 var query = FB.Data.query('select name, hometown_location, sex, pic_square from user where uid={0}', response.id);
			 query.wait(function(rows) {
			   
			   document.getElementById('name').innerHTML =
				 'Your name: ' + rows[0].name + "<br />" +
				 '<img src="' + rows[0].pic_square + '" alt="" />' + "<br />";
			 });
		});
	};
	function setStatus(){
		status1 = document.getElementById('status').value;
		FB.api(
		  {
			method: 'status.set',
			status: status1
		  },
		  function(response) {
			if (response == 0){
				//alert('Your facebook status not updated. Give Status Update Permission.');
			}
			else{
				//alert('Your facebook status updated');
			}
		  }
		);
	};
	/**/
	// post uid & get Flipped Image URL
	//
	function imgSuccesHandler(vent,res){
	  if(res.success){
		ownerObject.flippedImgUrl = res.flipImage;
		VGEVENT_GLOBALS.flippedImageLoaded(ownerObject.flippedImgUrl);
	  }
	  VGEVENT_GLOBALS.isNotBusy(res);
	};
	function imgErrorHandler(vent,res){
	  VGEVENT_GLOBALS.isNotBusy('error'+res);
	};
	var loadFlippedImage=function(id,handler){
	  
	  VGEVENT_GLOBALS.isBusy('flipping image');
	  
	  // if(flipImgModel)flipImgModel.destroy();
	  flipImgModel = Backbone.Model.extend({
	  success:'',
		  flipImage:'',
		  messgae:'',
		  url: 'app/api/_flipImage',
		  uid: id,
		  image_link: secureGraph+id+'/picture?type=large'
	  });

	  var imgcall = new flipImgModel();
	  imgcall.save({
		url: 'app/api/_flipImage',
		uid: id,
		image_link: secureGraph+id+'/picture?type=large'
	
		},{success:imgSuccesHandler,error:imgErrorHandler});  
	};
	/**/
	// post/save owner data
	//
	function ownerSuccesHandler(vent,res){
	  if(res.success){
		VGEVENT_GLOBALS.ownerDataResponse(ownerObject.experience_id);
	  }
	  res.onOwnerCheck = true;
	  VGEVENT_GLOBALS.isNotBusy(res);
	};
	function ownerErrorHandler(vent,res){
	  VGEVENT_GLOBALS.isNotBusy('error'+res);

	};
	var saveOwner=function(options){
	  VGEVENT_GLOBALS.isBusy('Saving owner');

	  if(!ownerModel){
		ownerModel = Backbone.Model.extend({
		url:'app/api/newExperience',
		success:''
		});
	  }
	  
	  var successCallback = function(vent, res){
	  	ownerObject.experience_id = res.experience_id;
	  	if(options){
	  		if(options.callback){
	  			options.callback(vent, res);
	  		}
	  	} else {
	  		ownerSuccesHandler(vent, res);
	  	}
	  }

	  var ownercall = new ownerModel();
	  if(ownerObject.id){
		  ownercall.save({
			  uid:ownerObject.id,
			  name:ownerObject.name,
			  email:ownerObject.email || "",
			  forceNewExp: options? options.forceNewExp : false
			},{success: successCallback ,error:ownerErrorHandler});  
		} else {
			login();
		}
	};

	var confirmExperience=function(message, email){
	  var confExpModel = Backbone.Model.extend({
		  url:'app/api/confirmExperience',
		  success:'',
	  });

	  var confirmCall = new confExpModel();
	  var callback = function(vent, res){
	  	
	  };

	  confirmCall.save({
		  uid:ownerObject.id,
		  name:ownerObject.name,
		  experience_id:ownerObject.experience_id,
		  message: message || 'nessun',
		  email: email
		},{success:callback,error:callback});  
	};


	//
	/**/
	// post/add friend data
	//
	function addFriendSuccesHandler(vent,res){
	  if(res.success){
		VGEVENT_GLOBALS.addFriendDataResponse(res.message);
	  }
	 
	  VGEVENT_GLOBALS.isNotBusy(res);
	};
	function addFriendErrorHandler(vent,res){
	  VGEVENT_GLOBALS.isNotBusy('error'+res);
	};
	var addFriend=function(expId, friendId, friendName, friendThumb){
	  VGEVENT_GLOBALS.isBusy('Saving friend');

	  //if(friendModel)friendModel.destroy();
	  friendModel = Backbone.Model.extend({
		  url:'app/api/addFriend',
		  success:''
	  });

	  var friendCall = new friendModel();
	  friendCall.save({
		  url:'app/api/addFriend',
		  success:'',
		  experience_id : expId,
		  friend_uid    : friendId,
		  friend_name   : friendName,
		  friend_thumb  : friendThumb
		},{success:addFriendSuccesHandler, error:addFriendErrorHandler});  
	};
	//
	/**/
	//
	// retrieve (POST)/ look for friends List data
	//

	function getFriendsListErrorHandler(vent,res){
	  VGEVENT_GLOBALS.isNotBusy('error'+res);
	};
	var getFlippedUrl=function(){
	  return 'app/api/'+ownerObject.flippedImgUrl;
	};

	var getFriends=function(experience_id, callback){
	  VGEVENT_GLOBALS.isBusy('Getting FriendsList');

	  //if(friendsListModel)friendsListModel.destroy();
	  friendsListModel = Backbone.Model.extend({
		  url:'app/api/friendsList',
		  success:''
	  });

	  var success = function(vent, res){
	  	if(callback ){
	  		callback(vent,res);
	  	}
	  	
	  	VGEVENT_GLOBALS.isNotBusy(res);
	  };

	  var friendsListCall = new friendsListModel();
	  friendsListCall.save({
		  url:'app/api/friendsList',
		  success:'',
		  experience_id : experience_id,
		},{success:success, error:getFriendsListErrorHandler});  
	};

	//
	/**/
	//
	// retrieve (POST)/ look for giornataStorta
	//
	function getGiornataStortaSuccesHandler(vent,res){
	  if(res.success){
	  }
	 
	  VGEVENT_GLOBALS.isNotBusy(res);
	};
	function getGiornataStortaErrorHandler(vent,res){
	  VGEVENT_GLOBALS.isNotBusy('error'+res);
	};
	var checkGiornataStortaWithIDs=function(uid, eid, callback){
	  VGEVENT_GLOBALS.isBusy('Getting FriendsList');

	  // if(giornataStortaModel)giornataStortaModel.destroy();
	  giornataStortaModel = Backbone.Model.extend({
		  url:'app/api/checkUser',

	  });
		if(uid && eid){
		  var giornataStortaCall = new giornataStortaModel();
		  giornataStortaCall.save({
			  success:'',
			  experience_id : eid,
			  uid: uid
			},{success: callback || getGiornataStortaSuccesHandler, error:getGiornataStortaErrorHandler});  
		} else {
			redirect();
		}
	};
	//
	/**/
  var getUserData = function(){
	var userData = _.clone(ownerObject);
	userData.profilePicture = secureGraph+userData.id+'/picture?type=large';

	return userData;
  }


  function couponSended(vent,res){
	  VGEVENT_GLOBALS.isNotBusy(res);
	};

	function couponSendedError(vent,res){
	  VGEVENT_GLOBALS.isNotBusy('error'+res);
	};

	var sendCoupon=function(firstName, lastName, date, experience_id, callback){
	  VGEVENT_GLOBALS.isBusy('Getting FriendsList');

	  var couponModel = Backbone.Model.extend({
		  url:'app/api/sendCoupon',

	  });

	  var couponCall = new couponModel();
	  couponCall.save({
		  success:'',
		  birthDate : date,
		  firstName : firstName,
		  lastName : lastName,
		  experience_id: experience_id
		},{success: callback || couponSended, error:couponSendedError});  
	};

	var getConfigInfo = function(){
		var config = _.clone(appConfig);
		return config;
	}

  return {
	init: init,
	getUserData: getUserData,
	loadFlippedImage:loadFlippedImage,
	saveOwner:saveOwner,
	confirmExperience:confirmExperience,
	addFriend:addFriend,
	getFriendsList:getFriends,
	getFlippedUrl:getFlippedUrl,
	graphStreamPublish:graphStreamPublish,
	streamPublish:streamPublish,
	sendRequestFromApp: sendRequestFromApp,
	checkGiornataStortaWithIDs:checkGiornataStortaWithIDs,
	sendCoupon: sendCoupon,
	getConfigInfo : getConfigInfo
  };

});