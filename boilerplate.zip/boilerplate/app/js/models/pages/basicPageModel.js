/*----------------------------------------------------------------------------------------- 

Use this as a refrence for creating new modules

-----------------------------------------------------------------------------------------*/

define([
  // These are path alias that we configured in our bootstrap
	'jQuery'
  , 'Underscore'
  , 'Backbone'
], function($, _, Backbone){
	var basicPageModel = Backbone.Model.extend({
	});
 	
	var newModel = function(){
		return new basicPageModel;	
	}

  return newModel;
  // What we return here will be used by other modules
});