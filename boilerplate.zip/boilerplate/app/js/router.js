/*----------------------------------------------------------------------------------------- 

  This is the router for the app.
  All the logic to handle pages should be declared in here

-----------------------------------------------------------------------------------------*/

define([
  'jQuery'
  , 'Underscore'
  , 'Backbone'
  , 'vgHear/js/events/EventsManager'
  ,	'vgHear/js/views/managers/middlewareManager'
  , 'vgHear/js/views/managers/transitionManager'
  , 'vgHear/js/views/managers/loaderManager'
  , 'app/js/models/Proxy/FBProxy'
  , 'app/js/views/pages/welcomePageView'

], function($, _, Backbone, VGEvent, middlewareManager, transitionManager, ldrManager, fbProxy, welcomePageView){
	var app_router;
	AppRouter = Backbone.Router.extend({
	initialize: function(args) {

		if(args.managers)
		{
		  _.each(args.managers, function(mgr, name)
		  {
			this[name] = mgr;
		  }, this);      
		}

		// hide the loader
		VGEvent.dispatcher.bind(VGEvent.VGEVENT_GLOBALS.AppIsNotBusy, function(args) {
			app_router.loader_mgr.hide();
		});

		//show the loader
		VGEvent.dispatcher.bind(VGEvent.VGEVENT_GLOBALS.AppIsBusy, function(args) {
			app_router.loader_mgr.show();
		});

		//fired on fb connected
		VGEvent.dispatcher.bind(VGEvent.VGEVENT_GLOBALS.UserConnectedToFB, function(args) {
		}); 

	}

	// here we are declaring the middle wares used by the router to show a page
	,	middleWares : [
				VGEvent.VGEVENT_GLOBALS.isBusy
			,	{method: "addPageAndGo", target: transitionManager}
			,	VGEvent.VGEVENT_GLOBALS.isNotBusy
		]
			
	, routes: {
		// Define some URL routes
		'welcome': 'welcomePage'

		// Default
		, '*actions': 'defaultAction'
	}

	, welcomePage: function(){
		// we can pass the VGEvent reference around to use in other components
		middlewareManager(welcomePageView, this.middleWares, {VGEvent: VGEvent});
	}
	
	, defaultAction: function(actions){
		fbProxy.init();
	}

  });

  var initialize = function(){
	app_router = new  AppRouter({ 'managers': {'loader_mgr': new ldrManager()} });
	Backbone.history.start();

	app_router.navigate("welcome",true)
  };
  return {
	 initialize: initialize
  };
});