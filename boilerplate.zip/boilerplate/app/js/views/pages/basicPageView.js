define([
		'jQuery'
	,	'Underscore'
	,	'Backbone'
	,	'text!../../../templates/pages/basicPage.html'
], function($, _, Backbone, templ, boxView, actionBtnMaker, dragGocciola, modalMessage){
	var basicPageView = Backbone.View.extend({
			tagName: 'div'
		, el: "#main"
		, className: 'internalPage'
		, template :  Handlebars.compile(templ)
		, render: function(){
			var that = this;
		}
	});
	
	var instantiateNew = function(options){
		var basicPage = new basicPageView(options);
		return basicPage;
	}

	return instantiateNew;
});