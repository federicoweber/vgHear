/******************************************************************************************

			welcomePageView.js | 2012

			Agency: vanGoGh
			Agency URL: http://vangogh-creative.it
			Author: Federico Weber
			Author URL: http://federicoweber.com


			<------------------------------------------------------------->
			
									!!!NOTES!!!

			The welcome page 

			<------------------------------------------------------------->

******************************************************************************************/

define([
		'jQuery'
	,	'Underscore'
	,	'Backbone'
	,	'app/js/models/pages/basicPageModel'
    ,	'app/js/views/pages/basicPageView'

], function($, _, Backbone, model, basicPageView){

	// Create the page model
	var welcomModel = model();
	welcomModel.set({"id": "welcomePage"}); 
	welcomModel.set({"content": " "}); 
	welcomModel.set({"welcomeMessage": "true"}); 

	//create the view 
	var	welcomePageView = basicPageView({'model': welcomModel});

	welcomePageView.render =  function(options){
		var that = this;
		if(this.model){
			$(this.el).html(this.template(this.model.toJSON()))
		}
	};

	return welcomePageView;
});
	