<?php

header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past

require '../../_/api/Slim/Slim.php';

//
// url to call
// http://vangoghlab.com/giornatastorta/reverse_image.php?uid=12345&image_link=
//
$app='';
$firstTime =false;
$user_profile='';

if(!$app){
	$app = new Slim();
}
$app->get('/loadFBProfilePicture/:id', 'loadImageFindById');

//
$app->post('/addFriend', 'addFriend');
$app->post('/friendsList', 'friendsList');
$app->post('/_flipImage', 'flipImage');
$app->post('/newExperience', 'newExperience');
$app->post('/confirmExperience', 'confirmExperience');
$app->post('/checkUser', 'checkUser');
$app->post('/couponEmail', 'couponEmail');
$app->post('/sendCoupon', 'sendCoupon');



$app->run();

?>